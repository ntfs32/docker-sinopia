# sinopia 开源 npm仓库 samman认证插件

## Install

```bash
npm set registry http://127.0.0.1:4873 //sinopia地址
npm install sinopia

```